/*
Author: Ilay Pilosof
Date: 5/11/2016
Purpose: The program prints my full name,ID and a nice message in 3 rows.
*/

#include <stdio.h>

void main() {
	printf("Ilay Pilosof\n304961519\nSome nice message!");
}